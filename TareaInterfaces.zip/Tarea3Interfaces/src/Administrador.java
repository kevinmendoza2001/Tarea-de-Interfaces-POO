public class Administrador implements Autenticable, Reportable, Gestionable {
    @Override
    public boolean iniciarSesion(String usuario, String clave) {
        return usuario.equals("admin") && clave.equals("admin123");
    }

    @Override
    public void generarReporte() {
        System.out.println("Administrador generando reportes financieros...");
    }

    @Override
    public void gestionarDatos() {
        System.out.println("Administrador gestionando datos completos del sistema...");
    }
}
