public class Cajero implements Autenticable, Gestionable {
    @Override
    public boolean iniciarSesion(String usuario, String clave) {
        return usuario.equals("cajero") && clave.equals("1234");
    }

    @Override
    public void gestionarDatos() {
        System.out.println("Cajero gestionando transacciones básicas...");
    }
}
