public class Main {
    public static void main(String[] args) {
        Autenticable cajero = new Cajero();
        Autenticable admin = new Administrador();
        Autenticable supervisor = new Supervisor();

        System.out.println("Cajero login: " + cajero.iniciarSesion("cajero", "1234"));
        ((Gestionable)cajero).gestionarDatos();

        System.out.println("Administrador login: " + admin.iniciarSesion("admin", "admin123"));
        ((Reportable)admin).generarReporte();
        ((Gestionable)admin).gestionarDatos();

        System.out.println("Supervisor login: " + supervisor.iniciarSesion("supervisor", "sup2026"));
        ((Reportable)supervisor).generarReporte();
    }
}
