public class HorarioAcademico implements Imprimible {
    @Override
    public void imprimir() {
        System.out.println("Imprimiendo Horario Académico...");
    }
}
