public class Certificado implements Imprimible {
    @Override
    public void imprimir() {
        System.out.println("Imprimiendo Certificado Académico...");
    }
}
