public class Main{
    static void main(String[] args){
        Imprimible certificado = new Certificado();
        Imprimible acta = new ActaNotas();
        Imprimible horario = new HorarioAcademico();

        certificado.imprimir();
        acta.imprimir();
        horario.imprimir();
    }
}