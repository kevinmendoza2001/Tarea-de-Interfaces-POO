public class ActaNotas implements Imprimible {
    @Override
    public void imprimir() {
        System.out.println("Imprimiendo Acta de Notas...");
    }
}
