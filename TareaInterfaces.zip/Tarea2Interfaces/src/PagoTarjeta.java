public class PagoTarjeta implements Pagable {
    @Override
    public void procesarPago(double monto) {
        if (monto > 0) {
            System.out.println("Pago con tarjeta procesado: $" + monto);
        } else {
            System.out.println("Error: El monto debe ser mayor a cero.");
        }
    }
}