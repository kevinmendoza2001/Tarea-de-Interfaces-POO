public class Transferencia implements Pagable {
    @Override
    public void procesarPago(double monto) {
        if (monto > 0) {
            System.out.println("Pago por transferencia procesado: $" + monto);
        } else {
            System.out.println("Error: El monto debe ser mayor a cero.");
        }
    }
}
