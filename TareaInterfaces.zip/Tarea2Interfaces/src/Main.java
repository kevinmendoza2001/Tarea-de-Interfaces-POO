public class Main {
    public static void main(String[] args) {
        Pagable efectivo = new PagoEfectivo();
        Pagable tarjeta = new PagoTarjeta();
        Pagable transferencia = new Transferencia();

        efectivo.procesarPago(100.0);
        tarjeta.procesarPago(250.5);
        transferencia.procesarPago(500.0);

        // Monto invalido
        efectivo.procesarPago(-50.0);
    }
}
